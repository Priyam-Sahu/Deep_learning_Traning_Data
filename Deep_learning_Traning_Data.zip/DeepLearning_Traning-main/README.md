# DeepLearning _Traning
In my Deep learning training journey, I set out to tackle a specific problem using a carefully chosen dataset.
